package com.service;

public interface Service {
	
	public void service();

}
