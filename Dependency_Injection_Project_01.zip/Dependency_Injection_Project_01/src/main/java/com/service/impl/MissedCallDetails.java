package com.service.impl;

import com.service.Service;

public class MissedCallDetails implements Service {

	public void service() {
		System.out.println("Here the Missed Call Details");
	}

}
