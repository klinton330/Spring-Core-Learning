package com.service.impl;

import com.service.Service;

public class DataUsageDetails implements Service{

	public void service() {
		System.out.println("Here the Data usage details");
		
	}

}
