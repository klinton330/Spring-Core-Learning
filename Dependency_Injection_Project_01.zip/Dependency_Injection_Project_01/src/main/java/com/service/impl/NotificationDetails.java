package com.service.impl;

import com.service.Service;

public class NotificationDetails implements Service {

	public void service() {
		System.out.println("Here the Notification Details");
	}

}
